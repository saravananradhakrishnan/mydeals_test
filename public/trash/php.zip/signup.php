<?php
$email=$_REQUEST["email"];
$password=$_REQUEST["password"];
$cpassword=$_REQUEST["cpassword"];
$fname=$_REQUEST["fname"];
$lname=$_REQUEST["lname"];
$mobile=$_REQUEST["mobile"];
$gender=$_REQUEST["gender"];
$emp=$_REQUEST["emp"];
$day=$_REQUEST["day"];
$month=$_REQUEST["month"];
$year=$_REQUEST["year"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$zip=$_REQUEST["zip"];
$captcha=$_REQUEST["captcha"];
//$mode="mobile";
$Jsoncallback=$_REQUEST['jsoncallback'];


echo count($emp);

foreach($emp as $val)
{
$emp_st.="&employment_status[]=".$val;
//echo $category;
}

//echo 'emp = '.$emp_st;
	//echo 'aaaa';
	

$url="http://api.mydeals247.com/users/create_user.json?user[email]=".urlencode($email)."&user[password]=".urlencode($password)."&user[password_confirmation]=".urlencode($cpassword)."&user[fname]=".urlencode($fname)."&user[lname]=".urlencode($lname)."&address[mobile]=".urlencode($mobile)."&user[gender]=".urlencode($gender)."&month=".urlencode($month)."&day=".urlencode($day)."&year=".urlencode($year).$emp_st."&address[city]=".urlencode($city)."&address[state]=".urlencode($state)."&address[country]=".urlencode($country)."&address[zip]=".urlencode($zip)."&captcha_valid=".urlencode($captcha)."&mode=mobile";

echo 'URL = '.$url;
	//echo 'bbbbb';
	
	$ch = curl_init();
	//echo 'ccccc';
	curl_setopt($ch, CURLOPT_POST, 1);
		//echo 'dddddd';
    curl_setopt($ch, CURLOPT_URL, $url);
		//echo 'eeeee';
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//echo 'fffffff';
    $data = curl_exec($ch);
	//echo 'ggggggg';
	//print_r($data);
	
	echo $Jsoncallback . '(' . $data . ');';
	
	?>