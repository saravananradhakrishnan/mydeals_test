<?php
$mid=$_REQUEST["mid"];
$name=$_REQUEST["name"];
$amt=$_REQUEST["amt"];
$qty=$_REQUEST["qty"];
$b_addr=$_REQUEST["b_addr"];
$s_addr=$_REQUEST["s_addr"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$zip=$_REQUEST["zip"];
$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST["jsoncallback"];

//$url="http://api.mydeals247.com/user_requests/prepare_buy/post.json?auth_token=".$auth_token."&mid=".urlencode($mid)."&qty=".urlencode($qty)."&bill_address=".urlencode($b_addr)."&ship_address=".urlencode($s_addr)."&postal_code=".urlencode($zip)."&name=".urlencode($name)."&city=".urlencode($city)."&state=".urlencode($state)."&redeemed_amt=".urlencode($amt);

//echo "URL: ".$url;

$url="http://api.mydeals247.com/user_requests/prepare_buy/post.json";

$datatopost = array (
"auth_token" => $auth_token,
"mid" => $mid,
"qty" => $qty,
"bill_address" =>$b_addr,
"ship_address" =>$s_addr,
"postal_code" =>$zip,
"name" =>$name,
"city" =>$city,
"state" =>$state,
"redeemed_amt" =>$amt

);


	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $datatopost);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';

?>