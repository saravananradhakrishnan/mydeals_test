<?php
$id=$_REQUEST["id"];
$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];     



//echo "ID = ". $id;
//echo "auth = ". $auth_token;
/*$datatopost = array (
"ad_id" => $id,
"auth_token" => $auth_token
);*/

$url= "http://api.mydeals247.com/coupons/get_user_quiz_status/get.json?auth_token=".$auth_token."&ad_id=".$id;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
	/*curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt ($ch, CURLOPT_POSTFIELDS, $datatopost);*/
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $data = curl_exec($ch);
    echo $Jsoncallback . '(' . $data . ');';
?>