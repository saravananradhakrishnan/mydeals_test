<?php
$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$info=$_REQUEST["info"];
$amenities=$_REQUEST["amenities"];
$cidate=$_REQUEST["cidate"];
$codate=$_REQUEST["codate"];
$nroom=$_REQUEST["nroom"];
$adult=$_REQUEST["adult"];
$children=$_REQUEST["children"];
$bnight=$_REQUEST["bnight"];
$total=$_REQUEST["total"];
$dfactor=$_REQUEST["dfactor"];
$auth_token=$_REQUEST["auth"];
$Jsoncallback=$_REQUEST['jsoncallback'];  


foreach($amenities as $val)
{
$amenity.="&amenity_ids[]=".$val;
//echo $amenity;
}

$url="http://api.mydeals247.com/user_requests/create/new.json?categ_id=".urlencode($category)."&user_request[buysell_category_id]=".urlencode($SCategory).$amenity."&user_request[city]=".urlencode($city)."&user_request[state]=".urlencode($state)."&user_request[country]=".urlencode($country)."&show_user_request_price=".urlencode($narea)."&user_request[item_info]=".urlencode($info)."&checkin_date=".urlencode($cidate)."&checkout_date=".urlencode($codate)."&user_request[no_of_rooms]=".urlencode($nroom)."&user_request[adult]=".urlencode($adult)."&user_request[children]=".urlencode($children)."&user_request[price]=".urlencode($bnight)."&user_request[grand_total]=".urlencode($total)."&user_request[descision_factor]=".urlencode($dfactor)."&term_agreement_decision=on&auth_token=".$auth_token;


//echo "URL: " . $url;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';

?>