
<?php
$user=$_REQUEST["user"];
$pass=$_REQUEST["pass"];
$Jsoncallback=$_REQUEST['jsoncallback'];
//echo "URL = ". $user;
   $url="http://api.mydeals247.com/my_deals/change_pass/reset.json?email=".urlencode($user)."&pass=".urlencode($pass);
   
//echo "URL = ". $url;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';
?>