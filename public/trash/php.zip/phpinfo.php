 <?
phpinfo();
 
?> 