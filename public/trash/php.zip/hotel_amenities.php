<?php
$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$iname=$_REQUEST["iname"];
$ispecification=$_REQUEST["ispecification"];
$nitems=$_REQUEST["nitems"];
$bitme=$_REQUEST["bitme"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$cidate=$_REQUEST["cidate"];
$codate=$_REQUEST["codate"];
$nroom=$_REQUEST["nroom"];
$adult=$_REQUEST["adult"];
$children=$_REQUEST["children"];
$bnight=$_REQUEST["bnight"];
$dfactor=$_REQUEST["dfactor"];
$Jsoncallback=$_REQUEST['jsoncallback'];  




$url="http://www.mydeals247.com/user_requests/list_amenities/get.json?=category".urlencode($category)."&SCategory=".urlencode($SCategory)."&iname=".urlencode($iname)."&ispecification=".urlencode($ispecification)."&nitems=".urlencode($nitems)."&bitme=".urlencode($bitme)."&city=".urlencode($city)."&state=".urlencode($state)."&country=".urlencode($country)."&narea=".urlencode($narea)."&cidate=".urlencode($cidate)."&codate=".urlencode($codate)."&nroom=".urlencode($nroom)."&adult=".urlencode($adult)."&children=".urlencode($children)."&bnight=".urlencode($bnight)."&dfactor=".urlencode($dfactor);
    
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);




    echo $Jsoncallback . '(' . $data . ');';



?>