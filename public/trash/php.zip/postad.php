<?php
	$error = "";
	$msg = "";
	$fileElementName = 'fileToUpload';
	$target = "upload/";
 $target = $target . basename( $_FILES['fileToUpload']['name']);
 $ok=1;
 	if(!empty($_FILES[$fileElementName]['error']))
	{
		switch($_FILES[$fileElementName]['error'])
		{
			case '1':
				$error = 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
				break;
			case '2':
				$error = 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
				break;
			case '3':
				$error = 'The uploaded file was only partially uploaded';
				break;
			case '4':
				$error = 'No file was uploaded.';
				break;
			case '6':
				$error = 'Missing a temporary folder';
				break;
			case '7':
				$error = 'Failed to write file to disk';
				break;
			case '8':
				$error = 'File upload stopped by extension';
				break;
			case '999':
			default:
				$error = 'No error code avaiable';
		}
}
elseif(empty($_FILES['fileToUpload']['tmp_name']) || $_FILES['fileToUpload']['tmp_name'] == 'none')
	{
		$error = 'No file was uploaded..';
	}else
	{
			//$msg .= " File Name: " . $_FILES['fileToUpload']['name'] . ", ";
			//$msg .= " File Size: " . @filesize($_FILES['fileToUpload']['tmp_name']);
			//$msg .= "Name= ".$name . "Id= ".$id;
			if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target))
			{
			
			
					$auth_token=$_REQUEST["auth_token"];
				    $cname=$_REQUEST["cname"];
					$category_id=$_REQUEST["categ"];
					$quiz_info=$_REQUEST["usp"];
					$emp=$_REQUEST["emp"];
					$vurl=$_REQUEST["vurl"];
					$target_url=$_REQUEST["comp_url"];
					$city=$_REQUEST["city"];
					$state=$_REQUEST["state"];
					$country=$_REQUEST["country"];
					$zipcode=$_REQUEST["zip"];
					$quiz_cost=$_REQUEST["budget"];
					$tbudget=$_REQUEST["tbudget"];
					
					foreach($emp as $val)
					{
			$emp_status.="&employment_status[]=".$val;
					//echo &key ." = ". $val;
					}
							//$deal_img=$_FILES['fileToUpload']['tmp_name'];

					$q1=$_REQUEST["q1"];
					$q2=$_REQUEST["q2"];
					$q3=$_REQUEST["q3"];
					$q4=$_REQUEST["q4"];
					$q5=$_REQUEST["q5"];
						
					echo "Employment Status: '" . $emp . "',\n";
					//echo "Question1: '" . $q1 . "',\n";
						
					$q1a1=$_REQUEST["q1a1"];
					$q1a2=$_REQUEST["q1a2"];
					$q1a3=$_REQUEST["q1a3"];
					$q2a1=$_REQUEST["q2a1"];
					$q2a2=$_REQUEST["q2a2"];
					$q2a3=$_REQUEST["q2a3"];
					$q3a1=$_REQUEST["q3a1"];
					$q3a2=$_REQUEST["q3a2"];
					$q3a3=$_REQUEST["q3a3"];
					$q4a1=$_REQUEST["q4a1"];
					$q4a2=$_REQUEST["q4a2"];
					$q4a3=$_REQUEST["q4a3"];
					$q5a1=$_REQUEST["q5a1"];
					$q5a2=$_REQUEST["q5a2"];
					$q5a3=$_REQUEST["q5a3"];
					$cans1=$_REQUEST["cans1"];
					$cans2=$_REQUEST["cans2"];
					$cans3=$_REQUEST["cans3"];
					$cans4=$_REQUEST["cans4"];
					$cans5=$_REQUEST["cans5"];
					$Jsoncallback=$_REQUEST['jsoncallback'];
													
					$deal_image= "http://makemyapplication.in/upload/".$_FILES['fileToUpload']['name'];
					
			
$url="http://api.mydeals247.com/deals/create/new.json?deal[name]=".urlencode($name)."&deal[description]=".urlencode($description)."&deal[highlights]=".urlencode($highlights)."&deal[category_id]=".urlencode($category_id)."&start_date=".urlencode($start_date)."&end_date=".urlencode($end_date)."&deal[base_price]=".urlencode($base_price)."&deal[max_qty]=".urlencode($max_qty)."&deal[split_coupon]=".urlencode($split_coupon)."&publish3=".urlencode($publish3)."&deal[city]=".urlencode($city)."&deal[state]=".urlencode($state)."&deal[country]=".urlencode($country)."&deal[zipcode]=".urlencode($zipcode)."&deal[url]=".urlencode($url)."&deal[deal_img]=&deal[terms_conditions]=".urlencode($terms_conditions)."&seller_valid=".urlencode($seller_valid)."&qty1=".urlencode($q1)."&qty2=".urlencode($q2)."&qty3=".urlencode($q3)."&qty4=".urlencode($q4)."&qty5=".urlencode($q5)."&disc1=".urlencode($d1)."&disc2=".urlencode($d2)."&disc3=".urlencode($d3)."&disc4=".urlencode($d4)."&disc5=".urlencode($d5)."deal[is_template]=".urlencode($is_template)."&upload_img=".urlencode($deal_image)."&auth_token=". urlencode($auth_token);
				
				
					
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	//echo "msg: '" . $msg . "'\n";
	//echo "image URL: '" . $deal_image . "'\n";
	//echo "URL: ". $url;
	echo $Jsoncallback . '(' . $data . ');';
	
	}		
	}
	
	/*echo "{";
	echo				"error: '" . $error . "',\n";
	echo				"msg: '" . $msg . "'\n";
	echo				"data: '". $data."'\n";
	//echo				"data: '" . $Jsoncallback . "'\n";
	echo "}";
	
	
					
					}
					}*/
					
	
	
	
?>