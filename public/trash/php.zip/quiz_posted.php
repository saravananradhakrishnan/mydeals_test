<?php
$group=$_REQUEST["group"];
$q_count=$_REQUEST["i"];
$disc=$_REQUEST["disc"];
$ad_id=$_REQUEST["id"];
$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


//echo $group." <br>";
//$value=explode(" ", $group);
//echo $group[0];
//echo $group[1];
//echo "total questions = " . $q_count;

if($q_count==2)
{

$datatopost = array (
"group1" => $group[0],
"group2" => $group[1],
"accept_disclaimer" => $disc,
"total_questions" => $q_count,
"ad_id" => $ad_id,
"auth_token" => $auth_token,
);	
}
if($q_count==3)
{
	
$datatopost = array (
"group1" => $group[0],
"group2" => $group[1],
"accept_disclaimer" => $disc,
"total_questions" => $q_count,
"ad_id" => $ad_id,
"auth_token" => $auth_token,
);	
}

if($q_count==4)
{

$datatopost = array (
"group1" => $group[0],
"group2" => $group[1],
"group3" => $group[2],
"accept_disclaimer" => $disc,
"total_questions" => $q_count,
"ad_id" => $ad_id,
"auth_token" => $auth_token,
);	
}
if($q_count==5)
{
$datatopost = array (
"group1" => $group[0],
"group2" => $group[1],
"group3" => $group[2],
"group4" => $group[3],
"accept_disclaimer" => $disc,
"total_questions" => $q_count,
"ad_id" => $ad_id,
"auth_token" => $auth_token,
);	
}

/*$i=1;
foreach($group as $val)
{
echo $val." ";
//$grp.="&group".$i."=".urlencode($val);

$i++;
}*/

//echo $grp;

//$url= "http://api.mydeals247.com/coupons/validate_quiz.json?accept_disclaimer=".$disc.urlencode($grp)."&total_questions=".$q_count."&ad_id=".$ad_id."&auth_token=".$auth_token;


$url= "http://api.mydeals247.com/coupons/validate_quiz.json";


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt ($ch, CURLOPT_POSTFIELDS, $datatopost);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$data = curl_exec($ch);
	//echo "---data ". $data." ended---";
    echo $Jsoncallback . '(' . $data . ');';
?>

