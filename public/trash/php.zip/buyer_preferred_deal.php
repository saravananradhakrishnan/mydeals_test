<?php
$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];     

$url="http://api.mydeals247.com/users/user_pref/get.json?auth_token=".urlencode($auth_token);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';
?>
















