<?php

$itemname=$_REQUEST["dname"];
$start_date=$_REQUEST["from"];
$end_date=$_REQUEST["to"];

$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


$url= "http://api.mydeals247.com/user_requests/search_requests/search.json?search=true&itemname=".urlencode($itemname)."&start_date=".urlencode($start_date)."&end_date=".urlencode($end_date)."&auth_token=".urlencode($auth_token);



    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $data = curl_exec($ch);
    echo $Jsoncallback . '(' . $data . ');';

?>