<?php

$plantype=$_REQUEST["plantype"];
$prefplan=$_REQUEST["prefplan"];
$mobnum=$_REQUEST["mobnum"];
$cmobnum=$_REQUEST["cmobnum"];
$operator=$_REQUEST["operator"];
$amt=$_REQUEST["amt"];
$uid=$_REQUEST["uid"];
$auth_token=$_REQUEST["auth"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


$url= "http://api.mydeals247.com/coupons/recharge_mobile_request.json";

$datatopost = array (
"auth_token" => $auth_token,
"user_recharge_request[mobile_no]" => $disc,
"user_recharge_request[mobile_operator]" => $operator,
"user_recharge_request[plan_type]" =>$plantype,
"user_recharge_request[prefered_plan]" =>$prefplan,
"user_recharge_request[recharge_amt]" =>$amt,
"user_recharge_request[user_id]" =>$uid

);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $datatopost);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $data = curl_exec($ch);
    echo $Jsoncallback . '(' . $data . ');';
?>