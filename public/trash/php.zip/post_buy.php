<?php
$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$iname=$_REQUEST["iname"];
$ispecification=$_REQUEST["ispecification"];
$nitems=$_REQUEST["nitems"];
$bitme=$_REQUEST["bitme"];
$total=$_REQUEST["total"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$tcondition=$_REQUEST["tcondition"];
$spreference=$_REQUEST["spreference"];
$auth_token=$_REQUEST["auth"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


$url="http://api.mydeals247.com/user_requests/create/new.json?categ_id=".urlencode($category)."&user_request[buysell_category_id]=".urlencode($SCategory)."&user_request[item_info]=".urlencode($iname)."&user_request[item_spec]=".urlencode($ispecification)."&user_request[number_of_items]=".urlencode($nitems)."&user_request[price]=".urlencode($bitme)."&user_request[grand_total]=".urlencode($total)."&user_request[city]=".urlencode($city)."&user_request[state]=".urlencode($state)."&user_request[country]=".urlencode($country)."&user_request[locality]=".urlencode($narea)."&user_request[item_condition]=".urlencode($tcondition)."&user_request[descision_factor]=".urlencode($spreference)."&auth_token=".urlencode($auth_token);


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';

?>