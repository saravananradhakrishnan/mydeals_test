<?php

echo "<pre>";
	print_r($_REQUEST);
echo "</pre>";


	$error = "";
	$msg = "";
	$fileElementName = 'fileToUpload';
	$target = "upload/";
 $target = $target . basename( $_FILES['fileToUpload']['name']) ;
 $ok=1;
 	if(!empty($_FILES[$fileElementName]['error']))
	{
		switch($_FILES[$fileElementName]['error'])
		{
			case '1':
				$error = 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
				break;
			case '2':
				$error = 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
				break;
			case '3':
				$error = 'The uploaded file was only partially uploaded';
				break;
			case '4':
				$error = 'No file was uploaded.';
				break;
			case '6':
				$error = 'Missing a temporary folder';
				break;
			case '7':
				$error = 'Failed to write file to disk';
				break;
			case '8':
				$error = 'File upload stopped by extension';
				break;
			case '999':
			default:
				$error = 'No error code avaiable';
		}
}
elseif(empty($_FILES['fileToUpload']['tmp_name']) || $_FILES['fileToUpload']['tmp_name'] == 'none')
	{
		$error = 'No file was uploaded..';
	}else
	{
			//$msg .= " File Name: " . $_FILES['fileToUpload']['name'] . ", ";
			//$msg .= " File Size: " . @filesize($_FILES['fileToUpload']['tmp_name']);
			//$msg .= "Name= ".$name . "Id= ".$id;
			if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target))
			{
			/*//$_FILES['filetoupload']['tmp_name'] = $_SERVER['DOCUMENT_ROOT']."/".$target.$_FILES['filetoupload']['name'];
			$msg.="file: ".$_SERVER['DOCUMENT_ROOT']."/".$target.$_FILES['filetoupload']['name'];
			}*/
			
					$auth_token=$_REQUEST["auth_token"];
				    $cname=$_REQUEST["cname"];
					$category_id=$_REQUEST["categ"];
					$quiz_info=$_REQUEST["usp"];
					$emp=$_REQUEST["emp"];
					$vurl=$_REQUEST["vurl"];
					$target_url=$_REQUEST["comp_url"];
					$city=$_REQUEST["city"];
					$state=$_REQUEST["state"];
					$country=$_REQUEST["country"];
					$zipcode=$_REQUEST["zip"];
					$quiz_cost=$_REQUEST["budget"];
					$tbudget=$_REQUEST["tbudget"];
					echo "aaaaaaaa";
					foreach($emp as $val)
					{
					echo "bbbbbbb";
			echo $emp_status.="&employment_status[]=".$val;
					//echo $category;
					}
							//$deal_img=$_FILES['fileToUpload']['tmp_name'];
echo "ccccccccc";
					
					
					$q1=$_REQUEST["q1"];
					$q2=$_REQUEST["q2"];
					$q3=$_REQUEST["q3"];
					$q4=$_REQUEST["q4"];
					$q5=$_REQUEST["q5"];
					
					
					echo "Employment Status: '" . $emp_status . "',\n";
					//echo "Question1: '" . $q1 . "',\n";
									
					
					$q1a1=$_REQUEST["q1a1"];
					$q1a2=$_REQUEST["q1a2"];
					$q1a3=$_REQUEST["q1a3"];
					$q2a1=$_REQUEST["q2a1"];
					$q2a2=$_REQUEST["q2a2"];
					$q2a3=$_REQUEST["q2a3"];
					$q3a1=$_REQUEST["q3a1"];
					$q3a2=$_REQUEST["q3a2"];
					$q3a3=$_REQUEST["q3a3"];
					$q4a1=$_REQUEST["q4a1"];
					$q4a2=$_REQUEST["q4a2"];
					$q4a3=$_REQUEST["q4a3"];
					$q5a1=$_REQUEST["q5a1"];
					$q5a2=$_REQUEST["q5a2"];
					$q5a3=$_REQUEST["q5a3"];
					
					$cans1=$_REQUEST["cans1"];
					$cans2=$_REQUEST["cans2"];
					$cans3=$_REQUEST["cans3"];
					$cans4=$_REQUEST["cans4"];
					$cans5=$_REQUEST["cans5"];
					$Jsoncallback=$_REQUEST['jsoncallback'];  
					
		
					
		}
		}			
					
	
	
	
?>

<!---------------- real estste Page  --------------->
<div data-role="page" id="register"> 
    
    <div  data-role="header" data-theme="a"> 
	<a href="home.html" data-icon="back" data-role="button" rel="external">Back</a>
    <h1>Mydeals247</h1> 
    </div> 
   
    <div align="center" data-role="content"> 

  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" id="frm2" enctype="multipart/form-data"> 
  <ul data-role="listview" data-inset="true"> 
  <li data-role="list-divider">Create Ad Campaign</li> 
  <li> 
 
			<fieldset data-role="controlgroup">
<INPUT TYPE="text" NAME="camp_name" id="camp_name" placeholder="Ad Campaign Name*"> 
			<span id="email_error"></span> 
			</fieldset>
            <fieldset data-role="controlgroup">
            <label for="select-choice-category"><strong>Category</strong></label>
            <select name="category" id="category">
               
				
            </select>
    
        </fieldset>
         <fieldset data-role="controlgroup">
			<INPUT TYPE="text" NAME="usp" id="usp" placeholder="Unique Selling Point:">
			<span id="mobile_error"></span>
	</fieldset>
        <fieldset data-role="controlgroup" >
		    	<legend><strong>Target Audience</strong></legend>
<input type="checkbox" name="checkbox-6" id="checkbox-6" class="custom" />
				<label for="checkbox-6">Currently Employed</label>

<input type="checkbox" name="checkbox-7" id="checkbox-7" class="custom" />
				<label for="checkbox-7">House Wife</label>

<input type="checkbox" name="checkbox-8" id="checkbox-8" class="custom" />
				<label for="checkbox-8">Looking for a job</label>
                
<input type="checkbox" name="checkbox-9" id="checkbox-9" class="custom" />
				<label for="checkbox-9">Student</label>
        </fieldset>
    <fieldset data-role="controlgroup">
<INPUT TYPE="text" NAME="vurl" id="vurl" placeholder="YouTube Video Url ?">
			<span id="mobile_error"></span>
	</fieldset>
	<fieldset data-role="controlgroup">
			<INPUT TYPE="text" NAME="curl" id="curl" placeholder="Company URL">
			<span id="country_error"></span>
    </fieldset>
   
   <fieldset data-role="controlgroup">			
			<label for="bclogo"><strong>Ad Image:</strong></label> 
<INPUT TYPE="file" NAME="fileToUpload" id="fileToUpload" url:"#",uploadOnSelect:"true"/>
			<span id="bclogo_error"></span>
   </fieldset> 
  

		<fieldset data-role="controlgroup">
			<INPUT TYPE="text" NAME="city" id="city" placeholder="City*"> 
			<span id="sqft_error"></span> 
	   </fieldset>
         <fieldset data-role="controlgroup">
        <INPUT TYPE="text" NAME="state" id="state" placeholder="State*"> 
		   </fieldset>
		<fieldset data-role="controlgroup">
		<INPUT TYPE="text" NAME="country" id="country" placeholder="country*"> 
		   </fieldset>
		<fieldset data-role="controlgroup">
              <input type="text" name="zip" id="zip" placeholder="Zip/Pin Code*" />
              <span id="datepicker_error"></span>
              
       </fieldset>
	
             <div class="ui-grid-a">
          		<div class="ui-block-a">
	            <a href="#postadv" data-theme="c" data-role="button" onClick="post();">Next Step</a>
                </div>
	           <div class="ui-block-b">
	           <a href="Buyer.html" data-role="button" data-theme="b" rel="external">Cancel</a>
               </div>
	         
	      </div>
	 </div>
	  </div>
    </li>
  </ul> 
 
    
	</div> 
</div> 

<!---------------- Credit  Page Ends  --------------->
<!---------------- postAdv2 --------------->
<div data-role="page" id="postadv"> 
    
    <div  data-role="header" data-theme="a"> 
	<a href="home.html" data-icon="back" data-role="button" rel="external">Back</a>
    <h1>Mydeals247</h1> 
    </div> 
   
    <div align="center" data-role="content"> 

  <ul data-role="listview" data-inset="true"> 
  <li data-role="list-divider">Define Ad Questionnaire</li> 
  <li> 
        <fieldset data-role="controlgroup">

            <select name="budget" id="budget" onChange="showdiv()">
                <option value="1">Budget per potential lead</option>
                <option value="10">Rs 10</option>
                <option value="15">Rs 15</option>
                <option value="20">Rs 20</option>
				<option value="25">Rs 25</option>

            </select>
    
        </fieldset>
	 	<fieldset data-role="controlgroup">
	 	<input type="text" name="tbudget" id="tbudget" placeholder="Total Budget(Rs)*">
	 	<span id="naria_error"></span>
            (Minimum Rs 2000)
        </fieldset>
   
   
			
	 	<fieldset data-role="controlgroup">
	 	<input type="text" name="q1" id="q1" placeholder="Question Title 1*">
	 	<span id="email_error"></span> 
	    </fieldset>
    
	 	<fieldset data-role="controlgroup">
    <table><tr><td>
			<INPUT TYPE="text" NAME="q1a1" id="q1a1" placeholder="Answers choice 1"></td>
            <td><INPUT TYPE="radio" NAME="ans1" id="ans1" value="1" style="width:20px; height:20px;"></td></tr></table>
			<span id="mobile_error"></span>
	</fieldset>
	<fieldset data-role="controlgroup">
    <table><tr><td>
			<INPUT TYPE="text" NAME="q1a2" id="q1a2" placeholder="Answers choice 2">
            </td>
            <td><input type="radio" name="ans1" id="ans1" value="2" style="width:20px; height:20px;"></td>
    </tr></table>
			<span id="country_error"></span>
    </fieldset>
   <fieldset data-role="controlgroup">	
   <table><tr><td>		
			<INPUT TYPE="text" NAME="q1a3" id="q1a3" placeholder="Answers choice 3">
            </td>
            <td><INPUT TYPE="radio" NAME="ans1" id="ans1" value="3" style="width:20px; height:20px;"></td></tr></table>
			<span id="naria_error"></span>
   </fieldset> 
  
		<fieldset data-role="controlgroup">
			<INPUT TYPE="text" NAME="q2" id="q2" placeholder="Question Title 2*"> 
            
			<span id="sqft_error"></span> 
	   </fieldset>
       <fieldset data-role="controlgroup">		
   <table><tr><td>		
			<INPUT TYPE="text" NAME="q2a1" id="q2a1" placeholder="Answers choice 1">
            </td>
            <td><INPUT TYPE="radio" NAME="ans2" id="ans2" style="width:20px; height:20px;"></td></tr></table>
			<span id="naria_error"></span>
   </fieldset>
        <table><tr><td>
              <input type="text" NAME="q2a2" id="q2a2" placeholder="Answers choice 2" />
              </td>
            <td><INPUT TYPE="radio" NAME="ans2" id="ans2" style="width:20px; height:20px;"></td></tr></table>
              <span id="sqft_error"></span>
              
       </fieldset>
            <fieldset data-role="controlgroup">
            <table><tr><td>
			<INPUT TYPE="text" NAME="q2a3" id="q2a3" placeholder="Answers choice 3"> 
            </td>
            <td><INPUT TYPE="radio" NAME="ans2" id="ans2" style="width:20px; height:20px;"></td></tr></table>
			<span id="bnight_error"></span>
          </fieldset>
          
	 <div id="q3" style="display:none">         
     <fieldset data-role="controlgroup">
			<INPUT TYPE="text" NAME="q3" id="" placeholder="Question Title 3*"> 
			<span id="email_error"></span> 
	</fieldset>
    <fieldset data-role="controlgroup">
    <table><tr><td>
			<INPUT TYPE="text" NAME="q3a1" id="q3a1" placeholder="Answers choice 1">
            </td>
   <td><INPUT TYPE="radio" NAME="ans3" id="ans3" style="width:20px; height:20px;"></td></tr></table>
			<span id="mobile_error"></span>
	</fieldset>
	<fieldset data-role="controlgroup">
     <table><tr><td>
			<INPUT TYPE="text" NAME="q3a2" id="q3a2" placeholder="Answers choice 2">
            </td>
            <td><INPUT TYPE="radio" NAME="ans3" id="ans3" style="width:20px; height:20px;"></td></tr></table>
			<span id="country_error"></span>
    </fieldset>
   <fieldset data-role="controlgroup">	
    <table><tr><td>		
			<INPUT TYPE="text" NAME="q3a3" id="q3a3" placeholder="Answers choice 3">
            </td>
            <td><INPUT TYPE="radio" NAME="ans3" id="ans3" style="width:20px; height:20px;"></td></tr></table>
			<span id="naria_error"></span>
   </fieldset> 
   </div>
   
   <div id="q4" style="display:none">
   
   <fieldset data-role="controlgroup">
			<INPUT TYPE="text" NAME="q4" id="q4" placeholder="Question Title 4*"> 
			<span id="email_error"></span> 
	</fieldset>
    <fieldset data-role="controlgroup">
     <table><tr><td>
			<INPUT TYPE="text" NAME="q4a1" id="q4a1" placeholder="Answers choice 1">
            </td>
            <td><INPUT TYPE="radio" NAME="ans4" id="ans4" style="width:20px; height:20px;"></td></tr></table>
			<span id="mobile_error"></span>
	</fieldset>
	<fieldset data-role="controlgroup">
     <table><tr><td>
			<INPUT TYPE="text" NAME="q4a2" id="q4a2" placeholder="Answers choice 2">
            </td>
            <td><INPUT TYPE="radio" NAME="ans4" id="ans4" style="width:20px; height:20px;"></td></tr></table>
			<span id="country_error"></span>
    </fieldset>
   <fieldset data-role="controlgroup">	
    <table><tr><td>		
			<INPUT TYPE="text" NAME="q4a3" id="q4a3" placeholder="Answers choice 3">
            </td>
            <td><INPUT TYPE="radio" NAME="ans4" id="ans4" style="width:20px; height:20px;"></td></tr></table>
			<span id="naria_error"></span>
   </fieldset> 
   </div>
   
<div id="q5" style="display:none">
   
   <fieldset data-role="controlgroup">

			<INPUT TYPE="text" NAME="q5" id="q5" placeholder="Question Title 5*"> 
			<span id="email_error"></span> 
	</fieldset>
    <fieldset data-role="controlgroup">
    <table><tr><td>	
			<INPUT TYPE="text" NAME="q5a1" id="q5a1" placeholder="Answers choice 1">
            </td>
            <td><INPUT TYPE="radio" NAME="ans5" id="ans5" style="width:20px; height:20px;"></td></tr></table>
			<span id="mobile_error"></span>
	</fieldset>
	<fieldset data-role="controlgroup">
    <table><tr><td>	
			<INPUT TYPE="text" NAME="q5a2" id="q5a2" placeholder="Answers choice 2">
            </td>
            <td><INPUT TYPE="radio" NAME="ans5" id="ans5" style="width:20px; height:20px;"></td></tr></table>
			<span id="country_error"></span>
    </fieldset>
   <fieldset data-role="controlgroup">		
   <table><tr><td>		
			<INPUT TYPE="text" NAME="q5a3" id="q5a3" placeholder="Answers choice 3">
            </td>
            <td><INPUT TYPE="radio" NAME="ans5" id="ans5" style="width:20px; height:20px;"></td></tr></table>
			<span id="naria_error"></span>
   </fieldset> 
            
</div>			
			
             <div class="ui-grid-a">
          		<div class="ui-block-a">
	            <input type="submit" name="submit" value="submit" />
				<a href="#" data-theme="c" data-role="button" id="post">Submit</a>
                </div>
	           <div class="ui-block-b">
	           <a href="Buyer.html" data-role="button" data-theme="b" rel="external">Cancel</a>
               </div>
	         
	      </div>
    </div>
	  </div>
    </li>
  </ul> 
 
</form> 
    
	</div> 
</div>