<?php
	$error = "";
	$msg = "";
	$fileElementName = 'fileToUpload';
	$target = "upload/";
 $target = $target . basename( $_FILES['fileToUpload']['name']) ;
 $ok=1;
 	if(!empty($_FILES[$fileElementName]['error']))
	{
		switch($_FILES[$fileElementName]['error'])
		{
			case '1':
				$error = 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
				break;
			case '2':
				$error = 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
				break;
			case '3':
				$error = 'The uploaded file was only partially uploaded';
				break;
			case '4':
				$error = 'No file was uploaded.';
				break;
			case '6':
				$error = 'Missing a temporary folder';
				break;
			case '7':
				$error = 'Failed to write file to disk';
				break;
			case '8':
				$error = 'File upload stopped by extension';
				break;
			case '999':
			default:
				$error = 'No error code avaiable';
		}
}
elseif(empty($_FILES['fileToUpload']['tmp_name']) || $_FILES['fileToUpload']['tmp_name'] == 'none')
	{
		$error = 'No file was uploaded..';
	}else
	{
			//$msg .= " File Name: " . $_FILES['fileToUpload']['name'] . ", ";
			//$msg .= " File Size: " . @filesize($_FILES['fileToUpload']['tmp_name']);
			//$msg .= "Name= ".$name . "Id= ".$id;
			if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target))
			{
			/*//$_FILES['filetoupload']['tmp_name'] = $_SERVER['DOCUMENT_ROOT']."/".$target.$_FILES['filetoupload']['name'];
			$msg.="file: ".$_SERVER['DOCUMENT_ROOT']."/".$target.$_FILES['filetoupload']['name'];
			}*/
			
					$auth_token=$_REQUEST["auth_token"];
				    $offer=$_REQUEST["offer"];
					$mos=$_REQUEST["mos"];
					$expire=$_REQUEST["expire"];
					$specification=$_REQUEST["specification"];
					$user_req_id=$_REQUEST["req_id"];
					$ship_charge=$_REQUEST["ship_charge"];
					$total=$_REQUEST["total"];
					$fee_agreed=$_REQUEST["fee_agreed"];
					$item_info=$_REQUEST["item_info"];
									
					
					$is_template=$_REQUEST["template"];
					$Jsoncallback=$_REQUEST['jsoncallback'];  
					
					echo "auth token = " . $auth_token;
$offer_image= "http://makemyapplication.in/upload/".$_FILES['fileToUpload']['name'];
					
			
$url="http://api.mydeals247.com/deals/saveoffer/post.json?&merchant_offer[offer_price]=".urlencode($offer)."&merchant_offer[mode_of_shipping]=".urlencode($mos)."&merchant_offer[shipping_charge]=".urlencode($ship_charge)."&merchant_offer[fee_agreed]=".urlencode($fee_agreed)."&term_agreement_decision=on&merchant_offer[minimum_offer_time]=".urlencode($expire)."&merchant_offer[item_info]=".urlencode($item_info)."&merchant_offer[buysell_img]=&merchant_offer[is_template]=".urlencode($is_template)."&template1=on&merchant_offer[total_price]=".urlencode($total)."&usr_req_id=".urlencode($user_req_id)."&upload_img=".urlencode($offer_image)."&auth_token=".$auth_token;

	echo "<br>URL: ". $url;
					
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	//echo "msg: '" . $msg . "'\n";
	//echo "image URL: '" . $deal_image . "'\n";
	
	echo $Jsoncallback . '(' . $data . ');';	
		
	}		
	}
	
	/*echo "{";
	echo				"error: '" . $error . "',\n";
	echo				"msg: '" . $msg . "'\n";
	echo				"data: '". $data."'\n";
	//echo				"data: '" . $Jsoncallback . "'\n";
	echo "}";*/
	
 Ok	
?>