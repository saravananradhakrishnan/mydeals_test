<?php

$categ_id=$_REQUEST["categ"];
$auth_token=$_REQUEST["auth_token"];
$user_type=$_REQUEST["user_type"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


foreach($categ_id as &$val)
{
$category.="&category_ids[]=".$val;
//echo $category;
}

$url= "http://api.mydeals247.com/my_deals/update_settings/update.json?user_type=".urlencode($user_type)."&auth_token=".urlencode($auth_token).$category;


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $data = curl_exec($ch);
    echo $Jsoncallback . '(' . $data . ');';
?>