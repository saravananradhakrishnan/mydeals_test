<?php
$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$iname=$_REQUEST["iname"];
$ispecification=$_REQUEST["ispecification"];
$nitems=$_REQUEST["nitems"];
$bitme=$_REQUEST["bitme"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$tcondition=$_REQUEST["tcondition"];
$spreference=$_REQUEST["spreference"];
$Jsoncallback=$_REQUEST['jsoncallback'];     






$url="http://api.mydeals247.com/buysell_categories/buysell_categories_json/get.json?=category".urlencode($category)."&SCategory=".urlencode($SCategory)."&iname=".urlencode($iname)."&ispecification=".urlencode($ispecification)."&nitems=".urlencode($nitems)."&bitme=".urlencode($bitme)."&city=".urlencode($city)."&state=".urlencode($state)."&country=".urlencode($country)."&narea=".urlencode($narea)."&tcondition=".urlencode($tcondition)."&sprefrence=".urlencode($sprefrence);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);



    echo $Jsoncallback . '(' . $data . ');';



?>