<?php
$name=$_REQUEST["name"];
$category_id=$_REQUEST["category_id"];
$ad_quize_info=$_REQUEST["ad_quiz_info"];
$employment_status=$_REQUEST["employment_status"];
$employment_status=$_REQUEST["employment_status"];
$employment_status=$_REQUEST["employment_status"];
$employment_status=$_REQUEST["employment_status"];
$video_url=$_REQUEST["video_url"];
$target_url=$_REQUEST["target_url"];
$coupon_img=$_REQUEST["coupon_img"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$zipcode=$_REQUEST["zipcode"];
$seller_valid=$_REQUEST["seller_valid"];
$per_quize_cost=$_REQUEST["per_quiz_cost"];
$Totalbudget=$_REQUEST['Totalbudget']; 
$questiontitle1=$_REQUEST['questiontitle1'];  
$answertitle11=$_REQUEST['answer-title1-1'];  
$answertitle12=$_REQUEST['answer-title1-2'];  
$answertitle13=$_REQUEST['answer-title1-3'];  
$correct_answer1=$_REQUEST['correct_answer1'];
$questiontitle2=$_REQUEST['question-title2'];
$answertitle21=$_REQUEST['answer-title2-1'];
$correct_answer2=$_REQUEST['correct_answer2'];  
$answertitle22=$_REQUEST['answer-title2-2']; 
$answertitle23=$_REQUEST['answer-title2-3']; 
$questiontitle3=$_REQUEST['question-title3']; 
$answertitle31=$_REQUEST['answer-title3-1'];  
$answertitle32=$_REQUEST['answer-title3-2'];
$correct_answer3=$_REQUEST['correct_answer3'];
$answertitle33=$_REQUEST['answer-title3-3'];
$questiontitle4=$_REQUEST['question-title4'];
$answertitle41=$_REQUEST['answer-title4-1'];
$answertitle42=$_REQUEST['answer-title4-2']; 
$answertitle43=$_REQUEST['answer-title4-3']; 
$correct_answer4=$_REQUEST['correct_answer4']; 
$questiontitle5=$_REQUEST['question-title5']; 
$answertitle51=$_REQUEST['answer-title5-1']; 
$answertitle52=$_REQUEST['answer-title5-2']; 
$answertitle53=$_REQUEST['answer-title5-3']; 
$correct_answer5=$_REQUEST['correct_answer5']; 
$total_questions=$_REQUEST['total_questions']; 
$auth_token=$_REQUEST['auth_token']; 






$url="http://api.mydeals247.com/coupons/create/create.json?=name".urlencode($name)."&name=".urlencode($name)."&ad_quize_info=".urlencode($ad_quize_info)."&employment_status =".urlencode($employment_status)."&employment_status=".urlencode($employment_status)."&employment_status=".urlencode($employment_status)."&employment_status=".urlencode($employment_status)."&video_url=".urlencode($video_url)."&target_url=".urlencode($target_url)."&coupon_img=".urlencode($coupon_img)."&city=".urlencode($city)."&state=".urlencode($state)."&country=".urlencode($country)."&zipcode=".urlencode($zipcode)."&seller_valid =".urlencode($seller_valid)."&per_quize_cost=".urlencode($per_quize_cost)."&Totalbudget=".urlencode($Totalbudget)."&questiontitle1=".urlencode($question-title1)."&answertitle11 =".urlencode($answer-title1-1)."&answertitle12 =".urlencode($answer-title1-2)."&answertitle13=".urlencode($answer-title1-3)."&correct_answer1=".urlencode($correct_answer1)."&questiontitle2=".urlencode($question-title2)."&answertitle21=".urlencode($answer-title2-1)."&correct_answer2=".urlencode($correct_answer2)."&answertitle22=".urlencode($answer-title2-2)."&answertitle23=".urlencode($answer-title2-3)."&questiontitle3=".urlencode($question-title3)."&answertitle31=".urlencode($answer-title3-1)."&answertitle32=".urlencode($answer-title3-2)."&correct_answer3=".urlencode($correct_answer3)."&answertitle33=".urlencode($answer-title3-3)."&questiontitle4 =".urlencode($question-title4)."&answertitle41=".urlencode($answer-title4-1)."&answertitle42=".urlencode($answer-title4-2)."&answertitle43=".urlencode($answer-title4-3)."&correct_answer4=".urlencode($correct_answer4)."&questiontitle5=".urlencode($question-title5)."&answertitle5-1=".urlencode($answer-title5-1)."&answertitle52=".urlencode($answer-title5-2)."&answertitle53=".urlencode($answer-title5-3)."&correct_answer5=".urlencode($correct_answer5)."&total_questions=".urlencode($total_questions)."&auth_token=".urlencode($auth_token);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);



    echo $Jsoncallback . '(' . $data . ');';



?>