
<?php
$user=$_REQUEST["user"];
$scode=$_REQUEST["code"];
$Jsoncallback=$_REQUEST['jsoncallback'];
//echo "URL = ". $user;
   $url="http://api.mydeals247.com/my_deals/check_pass_code_verf/verify.json?email=".urlencode($user)."&scode=".urlencode($scode);
   
//echo "URL = ". $url;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';
?>