<?php

$auth=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];

   $url="http://api.mydeals247.com/users/list_library_books/get.json?auth_token=".$auth;

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);

    echo $Jsoncallback . '(' . $data . ');';
?>