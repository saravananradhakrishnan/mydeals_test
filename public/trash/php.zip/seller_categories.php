<?php
/*$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$iname=$_REQUEST["iname"];
$ispecification=$_REQUEST["ispecification"];
$nitems=$_REQUEST["nitems"];
$bitme=$_REQUEST["bitme"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$tcondition=$_REQUEST["tcondition"];
$spreference=$_REQUEST["spreference"];*/

$session=$_REQUEST["session"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


/*$url="http://www.mydeals247.com/user_requests/create/new.json?=categ_id".urlencode($category).
        "&buysell_category_id=".urlencode($SCategory)."&item_info=".urlencode($iname)."&item_spec=".urlencode($ispecification).
        "&number_of_items=".urlencode($nitems)."&price=".urlencode($bitme)."&city=".urlencode($city)."&state=".urlencode($state).
        "&country=".urlencode($country)."&locality=".urlencode($narea)."&item_condition=".urlencode($tcondition).
        "&descision_factor=".urlencode($spreference);*/

		$url="URL: http://www.mydeals247.com/users/seller_pref/<user-id>/get.json";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt ($ch, CURLOPT_HTTPHEADER, array ('_session_id :'.$session)); //Sir, Here's the problem what I feel, While binding $session with _session_id. Parameter on server is _session_id and i've stored session id on localstorage in $session.
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	
    $data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';

?>