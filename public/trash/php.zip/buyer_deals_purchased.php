<?php
//$category=$_REQUEST["category"];
$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];     
//  $SCategory=51;
$url="http://api.mydeals247.com/deals/bought_deals/get.json?auth_token=".urlencode($auth_token);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	
    echo $Jsoncallback . '(' . $data . ');';

?>