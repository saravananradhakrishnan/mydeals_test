
<?php

$itemname=$_REQUEST["dname"];
$start_date=$_REQUEST["from"];
$end_date=$_REQUEST["to"];
$categ_id=$_REQUEST["categ_id"];
$deal_type=$_REQUEST["dtype"];
$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


$url= "http://api.mydeals247.com/deals/search_deal/get.json?search=true&itemname=".urlencode($itemname)."&start_date=".urlencode($start_date)."&end_date=".urlencode($end_date)."&categ_id=".urlencode($categ_id)."deal_type=".urlencode($deal_type)."&auth_token=".urlencode($auth_token);



    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $data = curl_exec($ch);
    echo $Jsoncallback . '(' . $data . ');';

?>