<?php
/*$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$iname=$_REQUEST["iname"];
$ispecification=$_REQUEST["ispecification"];
$nitems=$_REQUEST["nitems"];
$bitme=$_REQUEST["bitme"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$tcondition=$_REQUEST["tcondition"];
$spreference=$_REQUEST["spreference"];*/

$auth_token=$_REQUEST["auth_token"];
$Jsoncallback=$_REQUEST['jsoncallback'];   


$url= "http://api.mydeals247.com/user_requests/list_requests/get.json?auth_token=".urlencode($auth_token);

 

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $data = curl_exec($ch);
    echo $Jsoncallback . '(' . $data . ');';
?>