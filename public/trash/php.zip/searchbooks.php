<?php
//$q=urlencode(trim($_GET['q']));
$q=$_REQUEST["q"];
$Jsoncallback=$_REQUEST['jsoncallback'];  
//$q=urlencode("chetan bhagat");
$host="https://www.googleapis.com/books/v1/volumes?q=".urlencode($q)."&key=AIzaSyB4oEtbPLPimav6DLBu5O2XMCsfHrG80ZA";



    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $host);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,10);
    $data = curl_exec($ch);

//$data=file_get_contents("books.json");
$data=json_decode($data);

echo $Jsoncallback . '(' . $data . ');';

/*$items=$data->items;
$size=sizeof($items);
$i=0;
echo "<TABLE border='0' cellspacing='10' cellpadding='5'>";
while($i<$size)
{
$book=$items[$i];

//echo $book->id;

 $authors="";
 $title="";
 $subtitle="";
 $pub="";
 $pages="";
 $rating=0;
 $ratingTotal=0;
foreach($book->volumeInfo as $key => $value)
	{
    if($key=="title")
	$title=$value;

    if($key=="subtitle")
	$subtitle=$value;

    if($key=="authors")
	foreach($value as $val)
	$authors.=$val.",";
		
    if($key=="publisher")
	$pub=$value;

	if($key=="pageCount")
	$pages=$value;

	if($key=="averageRating")
	$rating=$value;

	if($key=="ratingsCount")
	$ratingTotal=$value;

	if($key=="imageLinks")
		{
		$thumb= $value->thumbnail;
		}
		
	
	}
    

	echo "<TD>
	<div class='book'>
	<img src='$thumb' /></div>";
	
	echo "<div class='desc'>
	<p class='name'>$title</b><br>
	<b>$subtitle</b>
	</p>
	<b>Authors:</b> $authors
	<br><b>Publisher:</b> $pub
	<br><b>Pages:</b> $pages
	<br><b>Avg Rating:</b> $rating
	<br><b>Total Votes:</b> $ratingTotal
	$flipkart
	</div>
	
	
	
	</TD>
	";
	
$i++;
}

echo "</TR></TABLE>";*/


?>