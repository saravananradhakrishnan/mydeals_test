<?php
$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$amenities=$_REQUEST["amenities"];
$cidate=$_REQUEST["cidate"];
$codate=$_REQUEST["codate"];
$nroom=$_REQUEST["nroom"];
$adult=$_REQUEST["adult"];
$children=$_REQUEST["children"];
$bnight=$_REQUEST["bnight"];
$dfactor=$_REQUEST["dfactor"];
$auth_token=$_REQUEST["auth"];
$Jsoncallback=$_REQUEST['jsoncallback'];     

foreach($amenities as $val)
{
$amen.="&amenity_ids[]=".$val;
//echo $category;
}

data:{category:category,SCategory:SCategory,amenities:amenities,city:city,state:state,country:country,narea:narea,cidate:cidate,codate:codate,nroom:nroom, adult:adult, children:children,bnight:bnight,dfactor:dfactor,auth:auth},


$url="http://api.mydeals247.com/user_requests/create/new.json?categ_id=".$category."&user_request[buysell_category_id]=".$SCategory.$amen."&user_request[city]=".$city."&user_request[state]=".$state."&user_request[country]=".$country."&show_user_request_price=".$narea."&user_request[item_info]=".urlencode($iname)."&user_request[no_of_bed_rooms]=".$nroom."&user_request[sq_feet]=".urlencode($sq_feet)."&start_date=".urlencode(start_date)."&end_date=".urlencode(end_date);"&user_request[price]=".urlencode($price)."&user_request[grand_total]=".urlencode($total)."&user_request[descision_factor]=".urlencode($spreference)."&auth_token=".urlencode($auth_token);


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';

?>