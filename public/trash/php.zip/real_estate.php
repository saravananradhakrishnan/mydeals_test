<?php
$category=$_REQUEST["category"];
$SCategory=$_REQUEST["SCategory"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$narea=$_REQUEST["narea"];
$iname=$_REQUEST["iname"];
$bedroom=$_REQUEST["bedroom"];
$sq_feet=$_REQUEST["sq_feet"];
$start_date=$_REQUEST["start_date"];
$end_date=$_REQUEST["end_date"];
$price=$_REQUEST["price"];
$total=$_REQUEST["total"];
$spreference=$_REQUEST["d_fact"];
$auth_token=$_REQUEST["auth"];
$Jsoncallback=$_REQUEST['jsoncallback'];     


$url="http://api.mydeals247.com/user_requests/create/new.json?categ_id=".urlencode($category)."&user_request[buysell_category_id]=".urlencode($SCategory)."&user_request[city]=".urlencode($city)."&user_request[state]=".urlencode($state)."&user_request[country]=".urlencode($country)."&show_user_request_price=".urlencode($narea)."&user_request[item_info]=".urlencode($iname)."&user_request[no_of_bed_rooms]=".urlencode($bedroom)."&user_request[sq_feet]=".urlencode($sq_feet)."&start_date=".urlencode(start_date)."&end_date=".urlencode(end_date);"&user_request[price]=".urlencode($price)."&user_request[grand_total]=".urlencode($total)."&user_request[descision_factor]=".urlencode($spreference)."&auth_token=".urlencode($auth_token);












    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';

?>