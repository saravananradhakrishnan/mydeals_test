<?php
$fname=$_REQUEST["fname"];
$lname=$_REQUEST["lname"];
$city=$_REQUEST["city"];
$state=$_REQUEST["state"];
$country=$_REQUEST["country"];
$zip=$_REQUEST["zip"];
$fax=$_REQUEST["fax"];
$b_add=$_REQUEST["b_add"];
$s_add=$_REQUEST["s_add"];
$auth_token=$_REQUEST["auth"];
$Jsoncallback=$_REQUEST["jsoncallback"];



$url= "http://api.mydeals247.com/users/update/update.json";

$datatopost = array (
"auth_token" => $auth_token,
"user[fname]" => $fname,
"user[lname]" => $lname,
"address[city]" =>$city,
"address[state]" =>$state,
"address[country]" =>$country,
"address[zip]" =>$zip,
"&address[fax]" =>$fax,
"&address[billing_addr]" =>$b_add,
"&address[shipping_addr]" =>$s_add
);


//$url="http://api.mydeals247.com/users/update/update.json?&user[fname]=".$fname."&user[lname]=".$lname."&address[city]=".$city."&address[state]=".$state."&address[country]=".$country."&address[zip]=".$zip."&address[fax]=".$fax."&address[billing_addr]=".$b_add."&address[shipping_addr]=".$s_add."&auth_token=".$auth_token;
        

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $datatopost);
   	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
	echo $Jsoncallback . '(' . $data . ');';

?>