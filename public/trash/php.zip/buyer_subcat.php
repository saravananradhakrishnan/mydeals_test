<?php
$category=$_REQUEST["category"];
$Jsoncallback=$_REQUEST['jsoncallback'];     
//  $SCategory=51;
$url="http://api.mydeals247.com/buysell_categories/buysell_sub_category_json/get.json?categ_id=".urlencode($category);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
    echo $Jsoncallback . '(' . $data . ');';
?>